To run:
From the main directory, run ``python runexperiment.py``.
This will go into /data/ and pull each set file then run methods from divideandconquer.py and dynamic.py
Outputs will be found in /output/.
Additionally, a graph comparing the different methods will be produced.

To run an individual set, use ipython to import findMaxSumDC or findMaxSumDP respectively, then pass
the set to the method.
